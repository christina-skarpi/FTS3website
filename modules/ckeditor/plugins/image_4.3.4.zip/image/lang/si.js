﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'si', {
	alertUrl: 'කරුණාකර රුපයේ URL ලියන්න',
	alt: 'විකල්ප ',
	border: 'සීමාවවල ',
	btnUpload: 'සේවාදායකය වෙත යොමුකිරිම',
	button2Img: 'ඔබට තෝරන ලද රුපය පරිවර්තනය කිරීමට අවශ්‍යද?',
	hSpace: 'HSpace',
	img2Button: 'ඔබට තෝරන ලද රුපය පරිවර්තනය කිරීමට අවශ්‍යද?',
	infoTab: 'රුපයේ තොරතුරු',
	linkTab: 'සබැඳිය',
	lockRatio: 'නවතන අනුපාතය ',
	menu: 'රුපයේ ගුණ',
	resetSize: 'නැවතත් විශාලත්වය වෙනස් කිරීම',
	title: 'රුපයේ ',
	titleButton: 'රුප බොත්තමේ ගුණ',
	upload: 'උඩුගතකිරීම',
	urlMissing: 'රුප මුලාශ්‍ර URL නැත.',
	vSpace: 'VSpace',
	validateBorder: 'මාඉම් සම්පුර්ණ සංක්‍යාවක් විය යුතුය.',
	validateHSpace: 'HSpace  සම්පුර්ණ සංක්‍යාවක් විය යුතුය',
	validateVSpace: 'VSpace සම්පුර්ණ සංක්‍යාවක් විය යුතුය.'
} );
